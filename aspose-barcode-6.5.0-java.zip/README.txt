Aspose.Barcode for Java 
==========================================================================

Aspose.BarCode for Java is a robust and reliable barcode generation and recognition component,
written in Java, it allows developers to quickly and easily add barcode generation and 
recognition functionality to their Java applications.

Aspose.BarCode for Java supports most established barcode standards and barcode specifications. 
It has the ability to export to multiple image formats including: BMP, EMF, GIF, JPEG, PNG, TIFF and WMF.

With Aspose.BarCode for Java, developers have full control over every aspect of the barcode image including: 
background color, bar color, image quality, rotation angle, x-dimension, captions, 
customer defined resolution and more. 
Aspose.BarCode can read and recognize most common 1D and 2D barcodes from any image and at any angle.


For more info see http://www.aspose.com/java/barcode-component.aspx

This distribution contains the following directories:

- lib       : Aspose.Barcode libraries for JDK 1.4 and above, API Documentation in html format
- examples  : Aspose Java Examples Dashboard application
- licenses  : Notices and Licenses required for redistribution of Aspose.Barcode libraries


For start please check
 - Programmer's Guide in http://www.aspose.com/docs/display/barcodejava/Home
 - API Docs in aspose-barcode-x.x.x.x-javadoc.jar


Required Software and Libraries
===============================

Note that you will have to install
- Java runtime 1.4 or above


http://www.aspose.com/
Copyright (c) 2008-2014 Aspose Pty Ltd. All Rights Reserved.