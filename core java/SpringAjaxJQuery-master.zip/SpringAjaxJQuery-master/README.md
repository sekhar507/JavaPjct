Spring MVC - Ajax jQuery
==============================

Exemplo de uso do Spring MVC com os recursos Ajax do jQuery. 

O projeto é referente ao tutorial postado no blog MBallem - Programando com Java 
	http://www.mballem.com/post/spring-mvc-ajax-jquery